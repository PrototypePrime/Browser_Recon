@echo off
:: BrowserRecon — Trust Setup Launcher v2.0
:: Runs Setup_Trust.ps1 with ExecutionPolicy Bypass so it is not blocked
:: by the local PowerShell script execution policy.
::
:: Usage:
::   Run_Setup.cmd              — Trust + sign EXE + sign collection scripts

net session >nul 2>&1
if %errorLevel% neq 0 (
    echo.
    echo  [!!] This script must be run as Administrator.
    echo       Right-click Run_Setup.cmd and choose "Run as administrator".
    echo.
    pause
    exit /b 1
)

PowerShell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Setup_Trust.ps1"
