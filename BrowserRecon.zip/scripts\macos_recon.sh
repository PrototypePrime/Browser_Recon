#!/bin/bash
# BrowserRecon - macOS Browser Artifact Collection Script
# Usage: chmod +x macos_recon.sh && ./macos_recon.sh [output_dir]
#
# TIP: Close all browsers before running to avoid locked-file skips.
# Full Disk Access must be granted to Terminal in System Preferences > Privacy.

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
OUTPUT_DIR="${1:-$SCRIPT_DIR}"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
COLLECT_DIR="$OUTPUT_DIR/browserrecon_$TIMESTAMP"

echo "============================================"
echo " BrowserRecon - macOS Artifact Collector"
echo "============================================"
echo ""

mkdir -p "$COLLECT_DIR"

copy_artifact() {
    local src="$1"
    local browser="$2"
    local artifact="$3"

    if [ -e "$src" ]; then
        local dest_dir="$COLLECT_DIR/$browser"
        mkdir -p "$dest_dir"
        local filename=$(basename "$src")
        local dest="$dest_dir/${artifact}_${filename}"
        cp "$src" "$dest" 2>/dev/null
        if [ $? -eq 0 ]; then
            echo "  [OK] $browser - $artifact"
            # Copy SQLite WAL/SHM sidecar files for database integrity
            [ -e "${src}-wal" ] && cp "${src}-wal" "${dest}-wal" 2>/dev/null
            [ -e "${src}-shm" ] && cp "${src}-shm" "${dest}-shm" 2>/dev/null
        else
            local bname=$(echo "$browser" | cut -d'_' -f1)
            echo "  [SKIP] $browser - $artifact (locked — close $bname or grant Full Disk Access to Terminal)"
        fi
    fi
}

copy_artifact_dir() {
    local src="$1"
    local browser="$2"
    local artifact="$3"

    if [ -d "$src" ]; then
        local dest_dir="$COLLECT_DIR/$browser"
        mkdir -p "$dest_dir"
        local dirname=$(basename "$src")
        cp -r "$src" "$dest_dir/${artifact}_${dirname}" 2>/dev/null
        if [ $? -eq 0 ]; then
            echo "  [OK] $browser - $artifact (dir)"
        else
            echo "  [SKIP] $browser - $artifact (dir, permission denied)"
        fi
    fi
}

# --- Chrome ---
echo ""
echo "Scanning Google Chrome..."
CHROME_BASE="$HOME/Library/Application Support/Google/Chrome"
if [ -d "$CHROME_BASE" ]; then
    for profile_dir in "$CHROME_BASE"/Default "$CHROME_BASE"/Profile\ *; do
        [ -d "$profile_dir" ] || continue
        profile=$(basename "$profile_dir")
        copy_artifact     "$profile_dir/History"          "Chrome_$profile" "History"
        copy_artifact     "$profile_dir/Network/Cookies"  "Chrome_$profile" "Cookies"
        copy_artifact     "$profile_dir/Cookies"          "Chrome_$profile" "Cookies"
        copy_artifact     "$profile_dir/Bookmarks"        "Chrome_$profile" "Bookmarks"
        copy_artifact_dir "$profile_dir/Extensions"       "Chrome_$profile" "Extensions"
    done
fi

# --- Edge ---
echo ""
echo "Scanning Microsoft Edge..."
EDGE_BASE="$HOME/Library/Application Support/Microsoft Edge"
if [ -d "$EDGE_BASE" ]; then
    for profile_dir in "$EDGE_BASE"/Default "$EDGE_BASE"/Profile\ *; do
        [ -d "$profile_dir" ] || continue
        profile=$(basename "$profile_dir")
        copy_artifact     "$profile_dir/History"          "Edge_$profile" "History"
        copy_artifact     "$profile_dir/Network/Cookies"  "Edge_$profile" "Cookies"
        copy_artifact     "$profile_dir/Cookies"          "Edge_$profile" "Cookies"
        copy_artifact     "$profile_dir/Bookmarks"        "Edge_$profile" "Bookmarks"
        copy_artifact_dir "$profile_dir/Extensions"       "Edge_$profile" "Extensions"
    done
fi

# --- Brave ---
echo ""
echo "Scanning Brave..."
BRAVE_BASE="$HOME/Library/Application Support/BraveSoftware/Brave-Browser"
if [ -d "$BRAVE_BASE" ]; then
    for profile_dir in "$BRAVE_BASE"/Default "$BRAVE_BASE"/Profile\ *; do
        [ -d "$profile_dir" ] || continue
        profile=$(basename "$profile_dir")
        copy_artifact     "$profile_dir/History"          "Brave_$profile" "History"
        copy_artifact     "$profile_dir/Network/Cookies"  "Brave_$profile" "Cookies"
        copy_artifact     "$profile_dir/Cookies"          "Brave_$profile" "Cookies"
        copy_artifact     "$profile_dir/Bookmarks"        "Brave_$profile" "Bookmarks"
        copy_artifact_dir "$profile_dir/Extensions"       "Brave_$profile" "Extensions"
    done
fi

# --- Firefox ---
echo ""
echo "Scanning Mozilla Firefox..."
FF_BASE="$HOME/Library/Application Support/Firefox/Profiles"
if [ -d "$FF_BASE" ]; then
    for profile_dir in "$FF_BASE"/*/; do
        [ -d "$profile_dir" ] || continue
        profile=$(basename "$profile_dir")
        copy_artifact "$profile_dir/places.sqlite"  "Firefox_$profile" "History_Bookmarks"
        copy_artifact "$profile_dir/cookies.sqlite" "Firefox_$profile" "Cookies"
        copy_artifact "$profile_dir/extensions.json" "Firefox_$profile" "Extensions"
    done
fi

# --- Safari ---
echo ""
echo "Scanning Safari..."
copy_artifact "$HOME/Library/Safari/History.db"              "Safari" "History"
copy_artifact "$HOME/Library/Cookies/Cookies.binarycookies"  "Safari" "Cookies"
copy_artifact "$HOME/Library/Safari/Bookmarks.plist"         "Safari" "Bookmarks"

# --- Opera ---
echo ""
echo "Scanning Opera..."
OPERA_BASE="$HOME/Library/Application Support/com.operasoftware.Opera"
if [ -d "$OPERA_BASE" ]; then
    copy_artifact     "$OPERA_BASE/History"         "Opera" "History"
    copy_artifact     "$OPERA_BASE/Network/Cookies" "Opera" "Cookies"
    copy_artifact     "$OPERA_BASE/Cookies"         "Opera" "Cookies"
    copy_artifact     "$OPERA_BASE/Bookmarks"       "Opera" "Bookmarks"
    copy_artifact_dir "$OPERA_BASE/Extensions"      "Opera" "Extensions"
fi

# --- Opera GX ---
echo ""
echo "Scanning Opera GX..."
OPERA_GX_BASE="$HOME/Library/Application Support/com.operasoftware.OperaGX"
if [ -d "$OPERA_GX_BASE" ]; then
    copy_artifact     "$OPERA_GX_BASE/History"         "OperaGX" "History"
    copy_artifact     "$OPERA_GX_BASE/Network/Cookies" "OperaGX" "Cookies"
    copy_artifact     "$OPERA_GX_BASE/Cookies"         "OperaGX" "Cookies"
    copy_artifact     "$OPERA_GX_BASE/Bookmarks"       "OperaGX" "Bookmarks"
    copy_artifact_dir "$OPERA_GX_BASE/Extensions"      "OperaGX" "Extensions"
fi

# --- Vivaldi ---
echo ""
echo "Scanning Vivaldi..."
VIVALDI_BASE="$HOME/Library/Application Support/Vivaldi"
if [ -d "$VIVALDI_BASE" ]; then
    for profile_dir in "$VIVALDI_BASE"/Default "$VIVALDI_BASE"/Profile\ *; do
        [ -d "$profile_dir" ] || continue
        profile=$(basename "$profile_dir")
        copy_artifact     "$profile_dir/History"          "Vivaldi_$profile" "History"
        copy_artifact     "$profile_dir/Network/Cookies"  "Vivaldi_$profile" "Cookies"
        copy_artifact     "$profile_dir/Cookies"          "Vivaldi_$profile" "Cookies"
        copy_artifact     "$profile_dir/Bookmarks"        "Vivaldi_$profile" "Bookmarks"
        copy_artifact_dir "$profile_dir/Extensions"       "Vivaldi_$profile" "Extensions"
    done
fi

# --- Arc ---
echo ""
echo "Scanning Arc..."
ARC_BASE="$HOME/Library/Application Support/Arc/User Data"
if [ -d "$ARC_BASE" ]; then
    for profile_dir in "$ARC_BASE"/Default "$ARC_BASE"/Profile\ *; do
        [ -d "$profile_dir" ] || continue
        profile=$(basename "$profile_dir")
        copy_artifact     "$profile_dir/History"          "Arc_$profile" "History"
        copy_artifact     "$profile_dir/Network/Cookies"  "Arc_$profile" "Cookies"
        copy_artifact     "$profile_dir/Cookies"          "Arc_$profile" "Cookies"
        copy_artifact     "$profile_dir/Bookmarks"        "Arc_$profile" "Bookmarks"
        copy_artifact_dir "$profile_dir/Extensions"       "Arc_$profile" "Extensions"
    done
fi

# Create ZIP
echo ""
echo "Creating ZIP archive..."
ZIP_PATH="$OUTPUT_DIR/browserrecon_collection_$TIMESTAMP.zip"
cd "$COLLECT_DIR" && zip -r "$ZIP_PATH" . -x ".*" >/dev/null 2>&1
rm -rf "$COLLECT_DIR"

echo ""
echo "============================================"
echo " Collection complete!"
echo " Archive: $ZIP_PATH"
echo " Import this ZIP into BrowserRecon"
echo "============================================"
