﻿# BrowserRecon - Windows Browser Artifact Collection Script
# Run as Administrator for best results (locked cookie/history files need backup privileges)
# Usage: .\windows_recon.ps1 [-OutputDir C:\path\to\output]
#
# TIP: Close all browsers before running to avoid locked-file skips.
# Running as Administrator enables backup-mode (robocopy /B) which can bypass most locks.

param(
    [string]$OutputDir = $PSScriptRoot
)

$ErrorActionPreference = "SilentlyContinue"

Write-Host "============================================" -ForegroundColor Cyan
Write-Host " BrowserRecon - Windows Artifact Collector" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

# Check for admin rights
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "  [WARN] Not running as Administrator." -ForegroundColor Yellow
    Write-Host "         Locked files (e.g. open browser cookies) may be skipped." -ForegroundColor Yellow
    Write-Host "         Re-run from an elevated PowerShell for best results." -ForegroundColor Yellow
    Write-Host ""
}

# Create output directory
New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$collectDir = Join-Path $OutputDir "browserrecon_$timestamp"
New-Item -ItemType Directory -Force -Path $collectDir | Out-Null

# ---------------------------------------------------------------------------
# Copy-BrowserFile
# Three-stage fallback:
#   1. Standard Copy-Item
#   2. FileStream with FileShare.ReadWrite  (reads even if browser has file open)
#   3. robocopy /B - Windows Backup-mode   (bypasses DAC locks; needs admin)
# After success, also copies companion SQLite WAL/SHM files if present.
# ---------------------------------------------------------------------------
function Copy-BrowserFile {
    param($Source, $BrowserName, $ArtifactType)
    if (-not (Test-Path $Source)) { return }

    $destDir  = Join-Path $collectDir $BrowserName
    New-Item -ItemType Directory -Force -Path $destDir | Out-Null
    $fileName = Split-Path $Source -Leaf
    $destFile  = Join-Path $destDir "${ArtifactType}_$fileName"
    $srcDir    = Split-Path $Source -Parent
    $copied    = $false

    # --- Stage 1: Standard copy ---
    try {
        Copy-Item -Path $Source -Destination $destFile -Force -ErrorAction Stop
        Write-Host "  [OK] $BrowserName - $ArtifactType" -ForegroundColor Green
        $copied = $true
    } catch {}

    # --- Stage 2: FileStream with ReadWrite sharing (works when browser is open) ---
    if (-not $copied) {
        try {
            $fs  = [System.IO.File]::Open(
                        $Source,
                        [System.IO.FileMode]::Open,
                        [System.IO.FileAccess]::Read,
                        [System.IO.FileShare]::ReadWrite)
            $buf = New-Object byte[] $fs.Length
            $null = $fs.Read($buf, 0, $buf.Length)
            $fs.Close()
            [System.IO.File]::WriteAllBytes($destFile, $buf)
            Write-Host "  [OK] $BrowserName - $ArtifactType (shared-read)" -ForegroundColor Yellow
            $copied = $true
        } catch { if ($null -ne $fs) { try { $fs.Close() } catch {} } }
    }

    # --- Stage 3: robocopy /B - backup mode bypasses file-share locks (admin only) ---
    if (-not $copied) {
        try {
            $tmpDir = Join-Path $env:TEMP "browserrecon_rb_$([Guid]::NewGuid().ToString('N'))"
            New-Item -ItemType Directory -Force -Path $tmpDir | Out-Null
            $null = robocopy $srcDir $tmpDir $fileName /B /NJH /NJS /NFL /NDL /NC /NS 2>&1
            $rbFile = Join-Path $tmpDir $fileName
            if (Test-Path $rbFile) {
                Move-Item $rbFile $destFile -Force
                Write-Host "  [OK] $BrowserName - $ArtifactType (backup-mode)" -ForegroundColor Yellow
                $copied = $true
            }
            Remove-Item $tmpDir -Recurse -Force -ErrorAction SilentlyContinue
        } catch {}
    }

    if (-not $copied) {
        $browserShort = $BrowserName.Split('_')[0]
        Write-Host "  [SKIP] $BrowserName - $ArtifactType (locked - close $browserShort and retry, or run as Admin)" -ForegroundColor Red
        return
    }

    # --- Copy SQLite WAL/SHM sidecar files for database integrity ---
    foreach ($ext in @("-wal", "-shm")) {
        $sidecar = $Source + $ext
        if (Test-Path $sidecar) {
            try {
                $fs2 = [System.IO.File]::Open(
                            $sidecar,
                            [System.IO.FileMode]::Open,
                            [System.IO.FileAccess]::Read,
                            [System.IO.FileShare]::ReadWrite)
                $buf2 = New-Object byte[] $fs2.Length
                $null = $fs2.Read($buf2, 0, $buf2.Length)
                $fs2.Close()
                [System.IO.File]::WriteAllBytes("$destFile$ext", $buf2)
            } catch { if ($null -ne $fs2) { try { $fs2.Close() } catch {} } }
        }
    }
}

function Copy-BrowserDir {
    param($Source, $BrowserName, $ArtifactType)
    if (Test-Path $Source) {
        $destDir = Join-Path $collectDir "$BrowserName"
        New-Item -ItemType Directory -Force -Path $destDir | Out-Null
        $dirName = Split-Path $Source -Leaf
        $destPath = Join-Path $destDir "${ArtifactType}_$dirName"
        try {
            Copy-Item -Path $Source -Destination $destPath -Recurse -Force
            Write-Host "  [OK] $BrowserName - $ArtifactType (dir)" -ForegroundColor Green
        } catch {
            Write-Host "  [SKIP] $BrowserName - $ArtifactType (dir, error)" -ForegroundColor Red
        }
    }
}

$localAppData = $env:LOCALAPPDATA
$appData = $env:APPDATA

# --- Chrome ---
Write-Host "`nScanning Google Chrome..." -ForegroundColor White
$chromeBase = "$localAppData\Google\Chrome\User Data"
if (Test-Path $chromeBase) {
    Get-ChildItem "$chromeBase" -Directory | Where-Object { $_.Name -match "^(Default|Profile \d+)$" } | ForEach-Object {
        $profile = $_.Name
        Copy-BrowserFile "$chromeBase\$profile\History"         "Chrome_$profile" "History"
        Copy-BrowserFile "$chromeBase\$profile\Network\Cookies" "Chrome_$profile" "Cookies"
        Copy-BrowserFile "$chromeBase\$profile\Cookies"         "Chrome_$profile" "Cookies"
        Copy-BrowserFile "$chromeBase\$profile\Bookmarks"       "Chrome_$profile" "Bookmarks"
        Copy-BrowserDir  "$chromeBase\$profile\Extensions"      "Chrome_$profile" "Extensions"
    }
}

# --- Edge ---
Write-Host "`nScanning Microsoft Edge..." -ForegroundColor White
$edgeBase = "$localAppData\Microsoft\Edge\User Data"
if (Test-Path $edgeBase) {
    Get-ChildItem "$edgeBase" -Directory | Where-Object { $_.Name -match "^(Default|Profile \d+)$" } | ForEach-Object {
        $profile = $_.Name
        Copy-BrowserFile "$edgeBase\$profile\History"         "Edge_$profile" "History"
        Copy-BrowserFile "$edgeBase\$profile\Network\Cookies" "Edge_$profile" "Cookies"
        Copy-BrowserFile "$edgeBase\$profile\Cookies"         "Edge_$profile" "Cookies"
        Copy-BrowserFile "$edgeBase\$profile\Bookmarks"       "Edge_$profile" "Bookmarks"
        Copy-BrowserDir  "$edgeBase\$profile\Extensions"      "Edge_$profile" "Extensions"
    }
}

# --- Brave ---
Write-Host "`nScanning Brave..." -ForegroundColor White
$braveBase = "$localAppData\BraveSoftware\Brave-Browser\User Data"
if (Test-Path $braveBase) {
    Get-ChildItem "$braveBase" -Directory | Where-Object { $_.Name -match "^(Default|Profile \d+)$" } | ForEach-Object {
        $profile = $_.Name
        Copy-BrowserFile "$braveBase\$profile\History"         "Brave_$profile" "History"
        Copy-BrowserFile "$braveBase\$profile\Network\Cookies" "Brave_$profile" "Cookies"
        Copy-BrowserFile "$braveBase\$profile\Cookies"         "Brave_$profile" "Cookies"
        Copy-BrowserFile "$braveBase\$profile\Bookmarks"       "Brave_$profile" "Bookmarks"
        Copy-BrowserDir  "$braveBase\$profile\Extensions"      "Brave_$profile" "Extensions"
    }
}

# --- Firefox ---
Write-Host "`nScanning Mozilla Firefox..." -ForegroundColor White
$ffBase = "$appData\Mozilla\Firefox\Profiles"
if (Test-Path $ffBase) {
    Get-ChildItem "$ffBase" -Directory | ForEach-Object {
        $profile = $_.Name
        Copy-BrowserFile "$ffBase\$profile\places.sqlite"  "Firefox_$profile" "History_Bookmarks"
        Copy-BrowserFile "$ffBase\$profile\cookies.sqlite" "Firefox_$profile" "Cookies"
        Copy-BrowserFile "$ffBase\$profile\extensions.json" "Firefox_$profile" "Extensions"
    }
}

# --- Opera ---
Write-Host "`nScanning Opera..." -ForegroundColor White
$operaBase = "$appData\Opera Software\Opera Stable"
if (Test-Path $operaBase) {
    Copy-BrowserFile "$operaBase\History"         "Opera" "History"
    Copy-BrowserFile "$operaBase\Network\Cookies" "Opera" "Cookies"
    Copy-BrowserFile "$operaBase\Cookies"         "Opera" "Cookies"
    Copy-BrowserFile "$operaBase\Bookmarks"       "Opera" "Bookmarks"
    Copy-BrowserDir  "$operaBase\Extensions"      "Opera" "Extensions"
}

# --- Opera GX ---
Write-Host "`nScanning Opera GX..." -ForegroundColor White
$operaGxBase = "$appData\Opera Software\Opera GX Stable"
if (Test-Path $operaGxBase) {
    Copy-BrowserFile "$operaGxBase\History"         "OperaGX" "History"
    Copy-BrowserFile "$operaGxBase\Network\Cookies" "OperaGX" "Cookies"
    Copy-BrowserFile "$operaGxBase\Cookies"         "OperaGX" "Cookies"
    Copy-BrowserFile "$operaGxBase\Bookmarks"       "OperaGX" "Bookmarks"
    Copy-BrowserDir  "$operaGxBase\Extensions"      "OperaGX" "Extensions"
}

# --- Vivaldi ---
Write-Host "`nScanning Vivaldi..." -ForegroundColor White
$vivaldiBase = "$localAppData\Vivaldi\User Data"
if (Test-Path $vivaldiBase) {
    Get-ChildItem "$vivaldiBase" -Directory | Where-Object { $_.Name -match "^(Default|Profile \d+)$" } | ForEach-Object {
        $profile = $_.Name
        Copy-BrowserFile "$vivaldiBase\$profile\History"         "Vivaldi_$profile" "History"
        Copy-BrowserFile "$vivaldiBase\$profile\Network\Cookies" "Vivaldi_$profile" "Cookies"
        Copy-BrowserFile "$vivaldiBase\$profile\Cookies"         "Vivaldi_$profile" "Cookies"
        Copy-BrowserFile "$vivaldiBase\$profile\Bookmarks"       "Vivaldi_$profile" "Bookmarks"
        Copy-BrowserDir  "$vivaldiBase\$profile\Extensions"      "Vivaldi_$profile" "Extensions"
    }
}

# --- Arc ---
Write-Host "`nScanning Arc..." -ForegroundColor White
$arcBase = "$localAppData\Arc\User Data"
if (Test-Path $arcBase) {
    Get-ChildItem "$arcBase" -Directory | Where-Object { $_.Name -match "^(Default|Profile \d+)$" } | ForEach-Object {
        $profile = $_.Name
        Copy-BrowserFile "$arcBase\$profile\History"         "Arc_$profile" "History"
        Copy-BrowserFile "$arcBase\$profile\Network\Cookies" "Arc_$profile" "Cookies"
        Copy-BrowserFile "$arcBase\$profile\Cookies"         "Arc_$profile" "Cookies"
        Copy-BrowserFile "$arcBase\$profile\Bookmarks"       "Arc_$profile" "Bookmarks"
        Copy-BrowserDir  "$arcBase\$profile\Extensions"      "Arc_$profile" "Extensions"
    }
}

# Create ZIP archive
Write-Host "`nCreating ZIP archive..." -ForegroundColor Cyan
$zipPath = "$OutputDir\browserrecon_collection_$timestamp.zip"
Compress-Archive -Path "$collectDir\*" -DestinationPath $zipPath -Force
Remove-Item -Recurse -Force $collectDir

Write-Host "`n============================================" -ForegroundColor Cyan
Write-Host " Collection complete!" -ForegroundColor Green
Write-Host " Archive: $zipPath" -ForegroundColor White
Write-Host " Import this ZIP into BrowserRecon" -ForegroundColor White
Write-Host "============================================" -ForegroundColor Cyan
