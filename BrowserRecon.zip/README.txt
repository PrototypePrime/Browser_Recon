╔══════════════════════════════════════════════════════════════════╗
║              BrowserRecon  v0.1.0  —  DFIR Edition              ║
║         Browser History & Artifact Forensic Analysis Tool        ║
╚══════════════════════════════════════════════════════════════════╝

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  ⚠  IMPORTANT — LAB USE ONLY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  BrowserRecon is a forensic analysis tool intended EXCLUSIVELY for:
    • Controlled lab environments
    • Authorized digital forensic investigations
    • SOC analyst workstations operating on forensic copies

  DO NOT use this tool on:
    • Production systems or live user machines
    • Systems without explicit written authorization
    • Any device where you do not own or are not authorized to
      examine the browser data

  All evidence ingestion is performed on collected ZIP archives
  (forensic copies), never directly from live browser databases.

  Misuse of this tool may violate computer fraud laws in your
  jurisdiction. You are solely responsible for authorized use.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


CONTENTS OF THIS PACKAGE
─────────────────────────
  BrowserRecon.exe          Portable single-file application (no install needed)
  BrowserRecon_Setup.msi    Standard Windows Installer package
  Run_Setup.cmd             Launch this first  (right-click → Run as administrator)
  Setup_Trust.ps1           Trust & sign script (MOTW removal, EXE signing, script signing)
  README.txt                This file

  scripts\
    windows_recon.ps1       Collection script for Windows targets (run as Admin)
    macos_recon.sh          Collection script for macOS targets   (run with sudo)
    linux_recon.sh          Collection script for Linux targets   (run with sudo)
    checksums.sha256        SHA256 checksums for shell scripts (generated on sign)


QUICK START  —  Run the Setup Launcher First
─────────────────────────────────────────────
Right-click  Run_Setup.cmd  → Run as administrator

  (Do NOT double-click Setup_Trust.ps1 directly — PowerShell's execution
   policy will block unsigned scripts. Run_Setup.cmd handles this for you.)

The script will automatically:
  ✓  Remove the "downloaded from internet" mark from BrowserRecon.exe
  ✓  Create a local code-signing certificate and sign the EXE
  ✓  Install the certificate into the Trusted Root store
  ✓  Sign windows_recon.ps1 with the same local certificate
  ✓  Generate SHA256 checksums for the shell collection scripts

After running the script, launch BrowserRecon.exe normally.


WHY WINDOWS MAY BLOCK THE EXE
──────────────────────────────
Defender SmartScreen may block applications that are not signed by a
commercial Certificate Authority and not yet known to Microsoft's
reputation service.

BrowserRecon is an internal DFIR tool built from auditable source code.
It does not require a commercial certificate — all trust issues can be
resolved locally using the methods in Setup_Trust.ps1.


MANUAL BYPASS OPTIONS (if you prefer step-by-step)
────────────────────────────────────────────────────

Option A — Unblock before extracting (easiest, no admin needed)
  1. Right-click the downloaded  BrowserRecon.zip
  2. Select Properties
  3. Tick  ☑ Unblock  at the bottom → Apply → OK
  4. Extract — SmartScreen will not block any extracted files

Option B — Install via MSI
  1. Right-click  BrowserRecon_Setup.msi → Properties → Unblock → OK
  2. Double-click to install
  3. Launch from Start Menu or Desktop shortcut

Option C — Self-sign (run Run_Setup.cmd as Administrator)
  Right-click Run_Setup.cmd → Run as administrator.
  Automates certificate creation, signing, and trust — covers SmartScreen.
  (Run_Setup.cmd launches Setup_Trust.ps1 with ExecutionPolicy Bypass so
   PowerShell's script policy does not block it.)


FIRST-RUN QUICK START (after trust is established)
────────────────────────────────────────────────────
  1. Launch BrowserRecon.exe
  2. Go to Evidence Ingestion → drag in the ZIP from the collection script
  3. Navigate to Timeline, Artifacts, Intelligence Center, Visual Insights
  4. For AI reports: configure Ollama endpoint in Settings first


COLLECTION SCRIPTS
───────────────────
Pre-bundled in the  scripts\  subfolder. Also available for download from
within the app (Evidence Ingestion page → Download Script button).

  scripts\windows_recon.ps1  — Windows  (Run as Administrator)
  scripts\macos_recon.sh     — macOS    (chmod +x && sudo ./macos_recon.sh)
  scripts\linux_recon.sh     — Linux    (chmod +x && sudo ./linux_recon.sh)

The Windows script (windows_recon.ps1) is Authenticode-signed by
Setup_Trust.ps1 using the same local certificate as the EXE, allowing it
to run without execution-policy warnings on machines that have completed
the trust setup.

The shell scripts (.sh) cannot be Authenticode-signed on Windows.
Verify their integrity using the checksums file:

  macOS:    sha256sum -c scripts\checksums.sha256
  Linux:    sha256sum -c scripts/checksums.sha256

Scripts save a ZIP archive to the same folder they are run from.
Upload that ZIP directly into BrowserRecon's Evidence Ingestion screen.

  IMPORTANT: Run collection scripts AFTER closing the target browser.
  Chromium-based browsers hold a WAL lock on their SQLite databases
  while running. Collecting from a live browser may yield incomplete
  or inconsistent history data.


KNOWN LIMITATIONS & IMPORTANT NOTES
──────────────────────────────────────
  1. Forensic copies only — Always collect via the provided scripts
     and work from the ZIP archive. Never point this tool at a live
     browser profile directory.

  2. SQLite WAL files — If the browser was running at collection time,
     some recent history entries may be missing (uncommitted WAL data).
     The tool handles WAL gracefully but cannot guarantee completeness
     for live sessions.

  3. AI Analysis requires Ollama — The AI report feature requires a
     locally running Ollama instance (https://ollama.com). It is NOT
     included in this package and requires separate installation.
     The app works fully without it; AI analysis is optional.

  4. Domain enrichment requires API keys — OTX (AlienVault) and
     VirusTotal lookups require your own API keys entered in Settings.
     Without keys, domain risk scoring is unavailable.

  5. Large datasets — Browser histories exceeding ~500,000 entries
     may cause slow initial loading. The app pages data to manage
     memory, but very large ingestions can take 1–2 minutes to process.

  6. Evidence data location — Ingested evidence is stored in:
        %APPDATA%\com.browserrecon.app\
     Clear this directory manually between unrelated cases to prevent
     data mixing.

  7. Multi-browser support — Currently tested against:
        Chrome, Chromium, Edge, Brave, Opera, Vivaldi, Arc (Windows)
        Firefox (Places schema: moz_places + moz_historyvisits)
     Firefox history, cookies, and bookmarks are fully supported.

  8. Extension data — Only Chromium-based extension manifests are
     extracted. Extension runtime data (storage, sync) is not ingested.

  9. Timestamps — All timestamps are stored and displayed in UTC.
     Conversion to local time uses the analyst workstation's timezone.
     For cross-timezone investigations, verify UTC values directly.

  10. No evidence integrity hashing — BrowserRecon does not compute
      SHA256 hashes of ingested files at this time. Maintain your own
      chain-of-custody documentation outside this tool.

  11. Shell script signing — The macOS and Linux collection scripts
      (.sh) cannot be Authenticode-signed on Windows. Verify their
      integrity via the bundled SHA256 checksums file before use on
      production systems.


PRIVACY & DATA HANDLING
─────────────────────────
  • All processing is 100% local — no telemetry, no cloud uploads
  • AI analysis routes through your local Ollama instance only
  • Domain enrichment (OTX / VirusTotal) uses your own API keys only
  • No data ever leaves the analyst workstation


──────────────────────────────────────────────────────────────────
BrowserRecon v0.1.0  |  Internal DFIR Tooling  |  Not for resale
FOR AUTHORIZED LAB AND FORENSIC USE ONLY
──────────────────────────────────────────────────────────────────
