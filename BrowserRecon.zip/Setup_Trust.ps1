#Requires -RunAsAdministrator
<#
.SYNOPSIS
    BrowserRecon — Trust & Windows Security Bypass Setup
    Resolves Defender SmartScreen blocks automatically.

.DESCRIPTION
    Runs three steps in sequence:
      1. Remove Mark of the Web (MOTW) from BrowserRecon.exe and all bundled scripts
      2. Create a self-signed code-signing cert, trust it, and sign the EXE
      3. Sign the bundled Windows collection script (scripts\windows_recon.ps1)
         so it runs without execution-policy warnings on analyst machines.
         Generate SHA256 checksums for the shell scripts (macos_recon.sh,
         linux_recon.sh) for integrity verification on macOS/Linux.

    All changes are scoped to this machine only.
    No internet connection required.
    Run as Administrator (right-click → Run with PowerShell).
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ── Colours ───────────────────────────────────────────────────────────────────
function Header([string]$text) {
    Write-Host ""
    Write-Host "  $text" -ForegroundColor Cyan
    Write-Host ("  " + ("─" * ($text.Length))) -ForegroundColor DarkGray
}
function OK([string]$text)   { Write-Host "  [OK]  $text" -ForegroundColor Green  }
function SKIP([string]$text) { Write-Host "  [--]  $text" -ForegroundColor DarkGray }
function WARN([string]$text) { Write-Host "  [!!]  $text" -ForegroundColor Yellow }
function ERR([string]$text)  { Write-Host "  [XX]  $text" -ForegroundColor Red    }
function INFO([string]$text) { Write-Host "        $text" -ForegroundColor White   }

# ── Banner ────────────────────────────────────────────────────────────────────
Clear-Host
Write-Host ""
Write-Host "  ╔══════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "  ║       BrowserRecon — Trust & Bypass Setup v2.0          ║" -ForegroundColor Cyan
Write-Host "  ║       Signs EXE + Collection Scripts                     ║" -ForegroundColor Cyan
Write-Host "  ╚══════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# ── Locate paths ──────────────────────────────────────────────────────────────
$ScriptDir  = Split-Path -Parent $MyInvocation.MyCommand.Path
$ExePath    = Join-Path $ScriptDir "BrowserRecon.exe"
$ScriptsDir = Join-Path $ScriptDir "scripts"
$WinScript  = Join-Path $ScriptsDir "windows_recon.ps1"

if (-not (Test-Path $ExePath)) {
    ERR "BrowserRecon.exe not found at: $ExePath"
    INFO "Place this script in the same folder as BrowserRecon.exe and try again."
    Write-Host ""; Read-Host "  Press Enter to exit"; exit 1
}
INFO "Found: $ExePath"

if (Test-Path $ScriptsDir) {
    INFO "Found scripts folder: $ScriptsDir"
} else {
    WARN "No 'scripts' subfolder found — collection scripts will not be signed."
}

# ══════════════════════════════════════════════════════════════════════════════
# STEP 1 — Remove Mark of the Web (Zone.Identifier ADS)
# ══════════════════════════════════════════════════════════════════════════════
Header "Step 1/3 — Remove 'Downloaded from Internet' Mark"

$zone = Get-Item -Path "$ExePath" -Stream "Zone.Identifier" -ErrorAction SilentlyContinue
if ($zone) {
    try {
        Unblock-File -Path $ExePath
        OK "Mark of the Web removed from BrowserRecon.exe"
    } catch {
        WARN "Could not remove MOTW: $_"
    }
} else {
    SKIP "No internet mark found on BrowserRecon.exe — already clean"
}

# Also unblock all scripts in the scripts\ subfolder
if (Test-Path $ScriptsDir) {
    Get-ChildItem $ScriptsDir -File | ForEach-Object {
        $s = Get-Item -Path $_.FullName -Stream "Zone.Identifier" -ErrorAction SilentlyContinue
        if ($s) {
            try { Unblock-File -Path $_.FullName; OK "MOTW removed from $($_.Name)" }
            catch { WARN "Could not unblock $($_.Name): $_" }
        }
    }
}

# ══════════════════════════════════════════════════════════════════════════════
# STEP 2 — Self-sign the EXE with a local trusted certificate
# ══════════════════════════════════════════════════════════════════════════════
Header "Step 2/3 — Code-Sign BrowserRecon.exe"

$CertSubject  = "CN=BrowserRecon DFIR, O=Internal DFIR Tooling, C=US"
$CertStore    = "Cert:\LocalMachine\My"
$TrustStore   = "Cert:\LocalMachine\Root"
$PfxPath      = Join-Path $env:TEMP "br_codesign_$([System.Guid]::NewGuid().ToString('N')).pfx"
$PfxPass      = ConvertTo-SecureString "BRtemp!$(Get-Random)" -AsPlainText -Force

# Find or create the certificate
$cert = Get-ChildItem $CertStore -ErrorAction SilentlyContinue |
        Where-Object { $_.Subject -eq $CertSubject -and $_.NotAfter -gt (Get-Date) } |
        Sort-Object NotAfter -Descending |
        Select-Object -First 1

if ($cert) {
    SKIP "Reusing existing certificate (expires $($cert.NotAfter.ToString('yyyy-MM-dd')))"
} else {
    INFO "Creating new self-signed code-signing certificate (4096-bit RSA, 5 years)..."
    $cert = New-SelfSignedCertificate `
        -Subject           $CertSubject `
        -CertStoreLocation $CertStore `
        -Type              CodeSigning `
        -KeyUsage          DigitalSignature `
        -KeyAlgorithm      RSA `
        -KeyLength         4096 `
        -NotAfter          (Get-Date).AddYears(5) `
        -HashAlgorithm     SHA256
    OK "Certificate created (thumbprint: $($cert.Thumbprint.Substring(0,16))...)"
}

# Install into Trusted Root if not already there
$trusted = Get-ChildItem $TrustStore -ErrorAction SilentlyContinue |
           Where-Object { $_.Thumbprint -eq $cert.Thumbprint }
if ($trusted) {
    SKIP "Certificate already in Trusted Root store"
} else {
    INFO "Installing certificate into Trusted Root CA store..."
    try {
        Export-PfxCertificate -Cert $cert -FilePath $PfxPath -Password $PfxPass | Out-Null
        Import-PfxCertificate  -FilePath $PfxPath -CertStoreLocation $TrustStore -Password $PfxPass | Out-Null
        Remove-Item $PfxPath -Force -ErrorAction SilentlyContinue
        OK "Certificate installed into Trusted Root CA store"
    } catch {
        WARN "Could not install to Trusted Root: $_"
    }
}

# Locate signtool.exe
INFO "Searching for signtool.exe..."
$signtool = (Get-Command signtool.exe -ErrorAction SilentlyContinue)?.Source
if (-not $signtool) {
    $patterns = @(
        "${env:ProgramFiles(x86)}\Windows Kits\10\bin\*\x64\signtool.exe",
        "${env:ProgramFiles}\Windows Kits\10\bin\*\x64\signtool.exe",
        "${env:ProgramFiles(x86)}\Windows Kits\8.1\bin\x64\signtool.exe"
    )
    foreach ($p in $patterns) {
        $hit = Get-Item $p -ErrorAction SilentlyContinue |
               Sort-Object DirectoryName -Descending | Select-Object -First 1
        if ($hit) { $signtool = $hit.FullName; break }
    }
}

if ($signtool) {
    INFO "Signing BrowserRecon.exe..."
    $result = & $signtool sign /sha1 $cert.Thumbprint /fd SHA256 /td SHA256 `
                  /tr "http://timestamp.digicert.com" $ExePath 2>&1
    if ($LASTEXITCODE -eq 0) {
        OK "BrowserRecon.exe signed successfully (timestamped)"
    } else {
        # Retry without timestamp server (offline fallback)
        $result2 = & $signtool sign /sha1 $cert.Thumbprint /fd SHA256 $ExePath 2>&1
        if ($LASTEXITCODE -eq 0) {
            OK "BrowserRecon.exe signed (no timestamp — offline mode)"
        } else {
            WARN "Signing failed. SmartScreen bypass may not apply."
            INFO $result
        }
    }
} else {
    WARN "signtool.exe not found — skipping EXE signing"
    INFO "SmartScreen bypass requires Windows SDK. Install from:"
    INFO "https://developer.microsoft.com/en-us/windows/downloads/windows-sdk/"
    INFO ""
    INFO "Manual command after installing SDK:"
    INFO "signtool sign /sha1 $($cert.Thumbprint) /fd SHA256 `"$ExePath`""
}

# ══════════════════════════════════════════════════════════════════════════════
# STEP 3 — Sign Collection Scripts
# ══════════════════════════════════════════════════════════════════════════════
Header "Step 3/3 — Sign Collection Scripts"

if (Test-Path $WinScript) {
    INFO "Signing scripts\windows_recon.ps1..."
    try {
        $sigResult = Set-AuthenticodeSignature -FilePath $WinScript -Certificate $cert `
                         -TimestampServer "http://timestamp.digicert.com" `
                         -HashAlgorithm SHA256 -ErrorAction Stop
        if ($sigResult.Status -eq "Valid") {
            OK "windows_recon.ps1 signed and timestamped"
        } else {
            # Retry without timestamp server (offline fallback)
            $sigResult2 = Set-AuthenticodeSignature -FilePath $WinScript -Certificate $cert `
                              -HashAlgorithm SHA256 -ErrorAction SilentlyContinue
            if ($sigResult2.Status -eq "Valid") {
                OK "windows_recon.ps1 signed (no timestamp — offline mode)"
            } else {
                WARN "PowerShell signing status: $($sigResult.StatusMessage)"
            }
        }
    } catch {
        WARN "Could not sign windows_recon.ps1: $_"
    }
} else {
    SKIP "scripts\windows_recon.ps1 not found — skipping"
}

# Shell scripts (.sh) cannot be Authenticode-signed on Windows.
# Generate SHA256 checksums for integrity verification on macOS/Linux.
if (Test-Path $ScriptsDir) {
    $shellScripts = Get-ChildItem $ScriptsDir -Filter "*.sh"
    if ($shellScripts.Count -gt 0) {
        $checksumPath = Join-Path $ScriptsDir "checksums.sha256"
        $lines = @()
        foreach ($sh in $shellScripts) {
            $hash = (Get-FileHash $sh.FullName -Algorithm SHA256).Hash.ToLower()
            $lines += "$hash  $($sh.Name)"
            INFO "$($sh.Name) → $hash"
        }
        $lines | Set-Content $checksumPath -Encoding UTF8
        OK "Checksums written to scripts\checksums.sha256"
        INFO "Verify on macOS/Linux: sha256sum -c checksums.sha256"
    }
}

# ══════════════════════════════════════════════════════════════════════════════
# DONE
# ══════════════════════════════════════════════════════════════════════════════
Write-Host ""
Write-Host "  ╔══════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "  ║                   Setup Complete                         ║" -ForegroundColor Green
Write-Host "  ╚══════════════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""
Write-Host "  Launch BrowserRecon.exe directly from this folder." -ForegroundColor White
Write-Host "  Collection scripts are ready in the scripts\ subfolder." -ForegroundColor DarkGray
Write-Host ""
Read-Host "  Press Enter to exit"
